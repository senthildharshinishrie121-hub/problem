# 📅 Attendance Predictor

A smart attendance dashboard that tells students how many classes they must attend (and how many they can safely skip) to avoid detention. Semester: **29 Aug 2026 – 29 Nov 2026**.

## Features
- Pick one of 10 class sections; the weekly timetable is expanded into every class of the semester (holidays excluded).
- Per-subject and overall attendance with status: **Safe / Watch / At risk / Detention zone**.
- Targets: 75% (detention limit), 80%, 85%, 90% (safe zone).
- Shows classes you can still skip, classes you must attend, and the streak needed to recover from detention.
- Leave planner: add a date range and see the projected final percentage instantly.
- Saved in the browser (`localStorage`); no backend, no build step.

## The maths
With `a` attended, `c` conducted, `r` remaining, `total = c + r` and target `T`:
- Must attend of remaining: `max(0, ceil(T·total/100) − a)`
- Can skip: `r − mustAttend` (negative means the target is unreachable)
- Recovery streak: `ceil((T·c − 100·a) / (100 − T))`

## Run locally
Open `index.html` in a browser (or `python -m http.server`).

## Add the real timetables
Edit `js/data.js`: one entry per class period per day, add real holidays, and add all 10 sections.

## Deploy free on GitHub Pages
1. Push this folder to a GitHub repo.
2. Settings → Pages → Source: `main` branch, `/ (root)`.
3. Your site goes live at `https://<username>.github.io/<repo>/`.

## Structure
```
index.html        page shell
css/style.css     styling
js/data.js        timetables, holidays, semester dates (edit me)
js/engine.js      pure calculation logic
js/app.js         UI and events
```
