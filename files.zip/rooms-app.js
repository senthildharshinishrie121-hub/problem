(() => {
  const D = window.ROOM_DATA, E = RoomEngine;
  const occ = E.buildOccupancy(D);
  const $ = s => document.querySelector(s);
  const F = ["G", "1st", "2nd", "3rd", "4th"];

  // ---- init controls ----
  $("#day").innerHTML = E.DAYS.map(d => `<option>${d}</option>`).join("");
  $("#floor").innerHTML = `<option value="">Any</option>` + D.floors.map((n, i) => `<option value="${i}">${n}</option>`).join("");
  const now = new Date(), mins = now.getHours() * 60;
  $("#day").value = E.DAYS[now.getDay()];
  $("#start").value = E.toStr(Math.min(Math.max(mins, E.toMin(D.open)), E.toMin(D.close) - 60));
  $("#duration").value = "60";

  const EXAMPLES = ["AC room on the ground floor for 2 hours", "Non-AC room on 2nd floor at 3pm for 60 students",
                    "Any room for 90 minutes on Friday at 11am", "AC room with capacity 80 tomorrow morning"];
  $("#examples").innerHTML = EXAMPLES.map(x => `<button class="ghost" data-ex="${x}">${x}</button>`).join("");

  const read = () => ({
    day: $("#day").value,
    start: E.toMin($("#start").value || D.open),
    duration: +$("#duration").value,
    floor: $("#floor").value === "" ? null : +$("#floor").value,
    ac: $("#ac").value === "" ? null : $("#ac").value === "1",
    minCap: $("#cap").value ? +$("#cap").value : null
  });

  function render() {
    const q = read(), end = q.start + q.duration, rooms = E.find(D, occ, q);
    $("#summary").textContent = `${q.day} ${E.toStr(q.start)}–${E.toStr(end)} · ${rooms.length} room${rooms.length === 1 ? "" : "s"} available`;
    if (!rooms.length) { $("#results").innerHTML = `<div class="panel">${E.suggestRelax(D, occ, q)}</div>`; return; }
    $("#results").innerHTML = D.floors.map((name, fl) => {
      const list = rooms.filter(r => r.floor === fl);
      if (!list.length) return "";
      return `<section class="floor"><h3>${name} <span class="badge">${list.length} free</span></h3><div class="grid">` +
        list.map(r => `<article class="card room ${r.ac ? "ac" : "nonac"}">
          <h3>Room ${r.id}<span class="badge">${r.ac ? "❄️ AC" : "Non-AC"}</span></h3>
          <p class="stats">Capacity: <b>${r.capacity}</b> seats</p>
          <p class="stats">Free until ${E.toStr(r.freeUntil)}</p></article>`).join("") + `</div></section>`;
    }).join("");
  }

  // ---- AI finder: parse text, mirror it into the controls, then search ----
  function ask(text) {
    const p = E.parseQuery(text), tags = [];
    if (p.day) $("#day").value = p.day;
    if (p.start != null) $("#start").value = E.toStr(p.start);
    if (p.duration) $("#duration").value = [30, 60, 90, 120, 180].includes(p.duration) ? p.duration : 180;
    $("#floor").value = p.floor != null && p.floor < D.floors.length ? p.floor : "";
    $("#ac").value = p.ac == null ? "" : p.ac ? "1" : "0";
    $("#cap").value = p.minCap ?? "";
    if (p.ac != null) tags.push(p.ac ? "AC" : "Non-AC");
    if (p.floor != null) tags.push(D.floors[p.floor] || `Floor ${p.floor}`);
    if (p.duration) tags.push(`${p.duration / 60} h`);
    if (p.minCap != null) tags.push(`≥ ${p.minCap} seats`);
    if (p.start != null) tags.push(`at ${E.toStr(p.start)}`);
    if (p.day) tags.push(p.day);
    $("#understood").innerHTML = tags.length
      ? "Understood: " + tags.map(t => `<span class="chip tag">${t}</span>`).join("")
      : "Couldn't detect any requirements, showing all free rooms.";
    render();
  }

  $("#askBtn").onclick = () => ask($("#ask").value);
  $("#ask").onkeydown = e => { if (e.key === "Enter") ask(e.target.value); };
  $("#examples").onclick = e => { const x = e.target.dataset.ex; if (x) { $("#ask").value = x; ask(x); } };
  document.querySelectorAll("section.controls select, section.controls input").forEach(el => el.addEventListener("change", render));
  render();
})();
