// EDIT ME: rooms + timetables for the Floor Manager.
// Real timetable format: sections["Section 1"].Mon = [{ period: 0, subject: "Maths", room: "G01" }, ...]
// `period` is an index into `periods` below. Replace the generated sample with the real 10 timetables.
window.ROOM_DATA = (() => {
  const periods = [["09:00","10:00"],["10:00","11:00"],["11:00","12:00"],["12:00","13:00"],
                   ["14:00","15:00"],["15:00","16:00"],["16:00","17:00"]]; // 13:00-14:00 lunch
  const floors = ["Ground Floor", "1st Floor", "2nd Floor"];
  const ids = ["G01","G02","G03","G04","101","102","103","104","201","202","203","204"];
  const caps = [40,60,30,120, 50,40,80,30, 60,45,90,35];
  const acs = [1,0,1,1, 0,1,0,0, 1,0,1,0];
  const rooms = ids.map((id, i) => ({ id, floor: Math.floor(i / 4), ac: !!acs[i], capacity: caps[i] }));

  // ---- SAMPLE timetable generator (clash-free: 10 sections, 12 rooms). Delete when real data is added. ----
  const days = ["Mon","Tue","Wed","Thu","Fri"], subs = ["Maths","Physics","DSA","English","Chemistry"];
  const sections = {};
  for (let i = 0; i < 10; i++) {
    const week = (sections[`Section ${i + 1}`] = {});
    days.forEach((d, di) => {
      week[d] = [];
      periods.forEach((_, p) => {
        if ((i * 3 + di + p) % 4 === 0) return; // free period for this section
        week[d].push({ period: p, subject: subs[(i + di + p) % subs.length], room: ids[(i + di * 3 + p) % ids.length] });
      });
    });
  }
  return { periods, floors, rooms, sections, open: "09:00", close: "17:00" };
})();
