// Pure logic: availability search + rule-based natural-language parser (works offline, no API key).
const RoomEngine = (() => {
  const DAYS = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  const toMin = s => { const [h, m] = s.split(":").map(Number); return h * 60 + m; };
  const toStr = m => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;

  // Index every class as "Day|Room" -> [{start,end,section,subject}]
  function buildOccupancy(data) {
    const map = new Map();
    for (const [section, week] of Object.entries(data.sections))
      for (const [day, list] of Object.entries(week))
        for (const c of list) {
          const [s, e] = data.periods[c.period], key = `${day}|${c.room}`;
          (map.get(key) || map.set(key, []).get(key)).push({ start: toMin(s), end: toMin(e), section, subject: c.subject });
        }
    return map;
  }

  // q: { day, start(min), duration(min), floor?, ac?, minCap? } -> rooms free for the WHOLE window
  function find(data, occ, q) {
    const end = q.start + q.duration, close = toMin(data.close);
    return data.rooms.filter(r =>
      (q.floor == null || r.floor === q.floor) &&
      (q.ac == null || r.ac === q.ac) &&
      (q.minCap == null || r.capacity >= q.minCap)
    ).flatMap(r => {
      const slots = occ.get(`${q.day}|${r.id}`) || [];
      if (slots.some(x => x.start < end && x.end > q.start)) return [];
      const next = slots.filter(x => x.start >= end).map(x => x.start);
      return [{ ...r, freeUntil: next.length ? Math.min(...next) : Math.max(close, end) }];
    });
  }

  // When nothing matches, find which single requirement to relax.
  function suggestRelax(data, occ, q) {
    const label = { minCap: "the capacity requirement", ac: "the AC/Non-AC requirement", floor: "the floor requirement" };
    for (const k of ["minCap", "ac", "floor"]) {
      if (q[k] == null) continue;
      const n = find(data, occ, { ...q, [k]: null }).length;
      if (n) return `No exact match. Without ${label[k]}, ${n} room${n > 1 ? "s are" : " is"} free.`;
    }
    return "No exact match. Try a different time, day or a shorter duration.";
  }

  // "AC room on the ground floor for 2 hours at 10am on Monday" -> partial query
  function parseQuery(text) {
    const t = text.toLowerCase(), q = {}; let m;
    if (/\bnon[\s-]?ac\b|non[\s-]?air|without (?:an? )?ac|no ac\b/.test(t)) q.ac = false;
    else if (/\bac\b|air[\s-]?condition/.test(t)) q.ac = true;

    const ord = { first: 1, second: 2, third: 3, fourth: 4 };
    if (/ground|\bgf\b/.test(t)) q.floor = 0;
    else if ((m = t.match(/\b(first|second|third|fourth)\s+floor/))) q.floor = ord[m[1]];
    else if ((m = t.match(/(\d)(?:st|nd|rd|th)?\s*floor|floor\s*(?:no\.?\s*)?(\d)/))) q.floor = +(m[1] || m[2]);

    if ((m = t.match(/(\d+(?:\.\d+)?)\s*(?:hours?|hrs?|h)\b/))) q.duration = Math.round(+m[1] * 60);
    else if ((m = t.match(/(\d+)\s*(?:minutes?|mins?)\b/))) q.duration = +m[1];
    else if (/half (?:an )?hour/.test(t)) q.duration = 30;
    else if (/\b(?:an|one) hour\b/.test(t)) q.duration = 60;

    m = t.match(/(\d+)\s*(?:students?|people|persons?|seats?|pax|members?)/) ||
        t.match(/(?:capacity|seating)\s*(?:of|for|:)?\s*(\d+)/) ||
        t.match(/\bfor\s+(\d+)\b(?!\s*(?:hours?|hrs?|h\b|minutes?|mins?|am|pm|:))/);
    if (m) q.minCap = +m[1];

    if ((m = t.match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)/))) q.start = (+m[1] % 12 + (m[3] === "pm" ? 12 : 0)) * 60 + (+m[2] || 0);
    else if ((m = t.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/))) q.start = +m[1] * 60 + +m[2];
    else if ((m = t.match(/\bat\s+(\d{1,2})\b(?!\s*(?:hours?|hrs?))/))) q.start = (+m[1] < 8 ? +m[1] + 12 : +m[1]) * 60;
    else if (/\bnoon\b/.test(t)) q.start = 720;
    else if (/after lunch|afternoon/.test(t)) q.start = 840;
    else if (/morning/.test(t)) q.start = 540;
    else if (/\bnow\b/.test(t)) { const n = new Date(); q.start = n.getHours() * 60 + n.getMinutes(); }

    const idx = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6 };
    if ((m = t.match(/\b(sun|mon|tues?|wed(?:nes)?|thu(?:rs?)?|fri|sat)(?:day)?\b/))) q.day = DAYS[idx[m[1].slice(0, 3)]];
    else if (/\btoday\b/.test(t)) q.day = DAYS[new Date().getDay()];
    else if (/\btomorrow\b/.test(t)) q.day = DAYS[(new Date().getDay() + 1) % 7];
    return q;
  }

  return { DAYS, toMin, toStr, buildOccupancy, find, suggestRelax, parseQuery };
})();
if (typeof module !== "undefined") module.exports = RoomEngine;
